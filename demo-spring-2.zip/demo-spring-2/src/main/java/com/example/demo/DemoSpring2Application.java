package com.example.demo;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.jdbc.core.JdbcTemplate;

@SpringBootApplication
public class DemoSpring2Application implements CommandLineRunner{
	
	@Autowired
	private JdbcTemplate jdbcTemplate;

	public static void main(String[] args) {
		SpringApplication.run(DemoSpring2Application.class, args);
	}

	@Override
	public void run(String... args) throws Exception {
		// TODO Auto-generated method stub
		System.out.println("Hello World!!");
	//	this.createUser();
	//	this.updateUser();
	//	this.deleteUser();
	//	this.readUserVer1();
	//	this.readUserVer2();
	}
	
	public void createUser() {
		String sql="insert into user(username,password,email,address,city,state,zip) values(?,?,?,?,?,?,?)";
		jdbcTemplate.update(sql,"jadeja","123fm","jadeja@gmail.com","pangali","saharnpur","delhi","98765");
		System.out.println("user created");
	}
	
	public void updateUser() {
		String sql="update user set username=? where ID=?";
		jdbcTemplate.update(sql,"lakhan",8);
		System.out.println("user updated");
	}
	public void deleteUser() {
		String sql="delete from user where id=?";
		jdbcTemplate.update(sql,1);
		System.out.println("user deleted");
	}
	
	public void readUserVer() {
		String sql="select * from user";
		List<Map<String,Object>> list= jdbcTemplate.queryForList(sql);
		System.out.println(list);
		System.out.println("user readed");
		
	}
	
	
	public void readUserVer1() {
		String sql="select * from user";
		List<User> list=jdbcTemplate.query(sql,new UserRowMapper());
		System.out.println(list);
		System.out.println("user readed");
		
	}
	
	@SuppressWarnings("deprecation")
	public void readUserVer2() {
		String sql="select * from user where id=?";
		User user=(User) jdbcTemplate.queryForObject(sql,new Object[] {1}, new UserRowMapper());
		System.out.println(user);
		
		
	}
	


}
