package com.example.demo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class HelloController {

	@Autowired
	private UserDao userdao;

	@GetMapping("/register")
	@ResponseBody
	public ModelAndView signupPage() {

		ModelAndView mv= new ModelAndView();
		mv.setViewName("register.jsp");
		return mv;


	}

	@PostMapping("/register")
	@ResponseBody
	public ModelAndView registeruserDb(User user) {

		this.userdao.create(user);

		ModelAndView mv= new ModelAndView();
		mv.setViewName("login.jsp");

		return mv;



	}

	@GetMapping("/login")
	@ResponseBody
	public ModelAndView signinPage() {
		ModelAndView mv= new ModelAndView();
		mv.setViewName("login.jsp");

		return mv;

	}

	@PostMapping("/login")
	@ResponseBody
	public ModelAndView validatesignIn(User user) {

		ModelAndView mv= new ModelAndView();

		try {
			boolean auth = this.userdao.validateUser(user);

			if(auth) {
				mv.setViewName("home.jsp");
			}else {
				mv.setViewName("login.jsp");
			}


		}catch(Exception e){
			mv.setViewName("opps.jsp");


		}
		return mv;





	}

	@PutMapping("/update")
    @ResponseBody
	public boolean update(User user) {
		this.userdao.update(user);
		System.out.println(user);
		return true;
	}

	@DeleteMapping("/delete")
	@ResponseBody
	public boolean delete(User user) {
		this.userdao.delete(user);
		System.out.println(user);
		return true;

	}



}
