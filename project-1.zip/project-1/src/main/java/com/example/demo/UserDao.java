package com.example.demo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;

import org.springframework.web.bind.annotation.RequestMapping;

@Component
public class UserDao {

	
	
	@Autowired
	private JdbcTemplate jdbcTemplate;
	
	@RequestMapping
	public boolean create(User user) {
		
		String sql= "insert into user(username,password,email,address,city,state,zip) values(?,?,?,?,?,?,?)";
		jdbcTemplate.update(sql, user.getUsername(),user.getPassword(),user.getEmail(),user.getAddress(),user.getCity(),user.getState(),user.getZip());
		return true;
		
	}
	
	

	@SuppressWarnings("deprecation")
	@RequestMapping
	public boolean validateUser(User user) {
		
		
		String sql="select * from user where username=?, password=? ";
		User userdb=jdbcTemplate.queryForObject(sql, new Object[] {user.getUsername(), user.getPassword()}, new UserRowMapper());
		if(userdb==null)
		{
			return false;
		}
		return true;
		
		
	}
	
	@RequestMapping
	public boolean update(User user) {
		
		String sql="update user set username=? where id=?";
		jdbcTemplate.update(sql,user.getUsername(),user.getId());
		return true;
		
	}
	@RequestMapping
	public boolean delete(User user) {
		String sql="delete from user where id=?";
		jdbcTemplate.update(sql,user.getId());
		return true;
	}
}
